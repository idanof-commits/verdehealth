export const metadata = {
  title: "Условия за ползване | VERDE HEALTH",
  description: "Правила и условия за използване на услугите.",
  robots: { index: false, follow: true },
  alternates: { canonical: "https://verdehealth.bg/legal/terms" },
  openGraph: { title: "Условия за ползване | VERDE HEALTH", description: "Правила и условия", url: "https://verdehealth.bg/legal/terms", siteName: "VERDE HEALTH", type: "website", locale: "bg_BG" }
};

export default function TermsPage() {
  const updated = "01.11.2025";
  return (
    <main style={{ minHeight: "70vh", background: "#FAFAF5", color: "#424242" }}>
      <section style={{ maxWidth: 960, margin: "0 auto", padding: "40px 16px" }}>
        <h1 style={{ fontSize: 28, fontWeight: 800 }}>Условия за ползване</h1>
        <p style={{ color: "#475569" }}>Последна актуализация: {updated}</p>
        <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16, marginTop: 16 }}>
          <h2>1. Общи положения</h2>
          <p>С достъп до сайта приемате тези условия.</p>
          <h2>2. Услуги</h2>
          <ul>
            <li>Генериране на индивидуални хранителни режими</li>
            <li>Онлайн консултации и материали</li>
          </ul>
          <h2>3. Контакт</h2>
          <p>Email: support@verdehealth.bg</p>
        </div>
      </section>
    </main>
  );
}
