export const metadata = {
  title: "Политика за поверителност | VERDE HEALTH",
  description: "GDPR-съобразена обработка на лични данни.",
  robots: { index: false, follow: true },
  alternates: { canonical: "https://verdehealth.bg/legal/privacy" },
  openGraph: { title: "Политика за поверителност | VERDE HEALTH", description: "GDPR политика", url: "https://verdehealth.bg/legal/privacy", siteName: "VERDE HEALTH", type: "website", locale: "bg_BG" }
};

export default function PrivacyPolicyPage() {
  const updated = "01.11.2025";
  return (
    <main style={{ minHeight: "70vh", background: "#FAFAF5", color: "#424242" }}>
      <section style={{ maxWidth: 960, margin: "0 auto", padding: "40px 16px" }}>
        <h1 style={{ fontSize: 28, fontWeight: 800 }}>Политика за поверителност</h1>
        <p style={{ color: "#475569" }}>Последна актуализация: {updated}</p>
        <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, padding: 16, marginTop: 16 }}>
          <h2>1. Какви данни събираме</h2>
          <ul>
            <li>Идентификационни: име, имейл, телефон</li>
            <li>Антропометрични: възраст, тегло, ръст, активност</li>
            <li>Предпочитания/непоносимости и данни от въпросници</li>
          </ul>
          <h2>2. Цели на обработката</h2>
          <ul>
            <li>Изготвяне на индивидуални планове и препоръки</li>
            <li>Проследяване на прогрес и подобряване на услугите</li>
          </ul>
          <h2>3. Права и контакти</h2>
          <p>Email: privacy@verdehealth.bg</p>
        </div>
      </section>
    </main>
  );
}
