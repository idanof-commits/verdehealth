"use client";
import React, { useMemo, useState } from "react";

type Form = {
  full_name?: string; email?: string; phone?: string; sex?: "male"|"female";
  age?: number; height_cm?: number; weight_kg?: number;
  waist_cm?: number; hip_cm?: number;
  activity?: "sedentary"|"light"|"moderate"|"active"|"very_active";
  goal?: "loss"|"gain"|"maintain";
  meals_per_day?: number;
  fasting_window?: string;
  disliked?: string;
};
type PlanDay = { day: string; type: "standard"|"unloading"; kcal: number; notes?: string; meals: { name: string; kcal: number; description: string; macros: { p:number; f:number; c:number } }[] };
type Plan = { meta: { kcalTarget:number; mealsPerDay:number; style:string; fasting?:string }, days: PlanDay[] };

export default function IntakePage(){
  const [form, setForm] = useState<Form>({ sex:"female", activity:"light", goal:"loss", meals_per_day:2, fasting_window:"12:00–20:00" });
  const [submitted, setSubmitted] = useState(false);
  const [plan, setPlan] = useState<Plan|null>(null);

  const af = useMemo(() => ({ sedentary:1.2, light:1.375, moderate:1.55, active:1.725, very_active:1.9 }[form.activity||"light"]), [form.activity]);
  const bmr = useMemo(() => calcBMR(form), [form]);
  const tdee = useMemo(() => Math.round(bmr * af), [bmr, af]);
  const deficitPct = useMemo(() => (form.goal==="loss"?0.25:form.goal==="gain"?-0.15:0), [form.goal]);
  const kcalTarget = useMemo(() => Math.round(tdee*(1-deficitPct)), [tdee, deficitPct]);
  const whr = useMemo(() => {
    const w = Number(form.waist_cm||0), h=Number(form.hip_cm||0);
    if(!w || !h) return undefined;
    return w/h;
  }, [form.waist_cm, form.hip_cm]);
  const whrRisk = useMemo(()=>{
    if(!whr) return undefined;
    if(form.sex==="male") return whr>1?"Висок":"Нормален";
    return whr>0.85?"Висок":"Нормален";
  }, [whr, form.sex]);

  const macros = useMemo(()=>({ protein_g: Math.round(kcalTarget*0.30/4), fat_g: Math.round(kcalTarget*0.35/9), carbs_g: Math.round(kcalTarget*0.35/4) }), [kcalTarget]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = buildPayload(form, { bmr, tdee, kcalTarget, whr, whrRisk, macros });
    setSubmitted(true);
    try{
      const res = await fetch("/api/plan/generate", { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify(payload) });
      await res.json();
      alert("Успешно изпратено към API.");
    }catch(err:any){
      alert("Грешка при изпращане към API.");
    }
  };

  return (
    <main style={{ minHeight: "70vh" }}>
      <section style={{ maxWidth: 1040, margin: "0 auto", padding: "24px 16px" }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, marginBottom: 8 }}>Въпросник за хранителен план</h1>
        <p style={{ color: "#475569", marginBottom: 12 }}>Попълни данните, изчисли BMR/TDEE и генерирай 14‑дневен план.</p>

        <form onSubmit={onSubmit} style={{ display:"grid", gap:12, background:"#fff", border:"1px solid #e5e7eb", borderRadius:12, padding:16 }}>
          <Row>
            <Input label="Име и фамилия" value={form.full_name||""} onChange={v=>setForm({...form, full_name:v})} />
            <Input label="E-mail" value={form.email||""} onChange={v=>setForm({...form, email:v})} />
            <Input label="Телефон" value={form.phone||""} onChange={v=>setForm({...form, phone:v})} />
          </Row>
          <Row>
            <Select label="Пол" value={form.sex||"female"} options={[["male","Мъж"],["female","Жена"]]} onChange={v=>setForm({...form, sex:v as any})} />
            <InputNumber label="Възраст (г.)" value={form.age||""} onChange={v=>setForm({...form, age:Number(v)||undefined})} />
            <Select label="Активност" value={form.activity||"light"} options={[["sedentary","Неактивен"],["light","Слабо активен"],["moderate","Средно активен"],["active","Високо активен"],["very_active","Изкл. активен"]]} onChange={v=>setForm({...form, activity:v as any})} />
          </Row>
          <Row>
            <InputNumber label="Ръст (см)" value={form.height_cm||""} onChange={v=>setForm({...form, height_cm:Number(v)||undefined})} />
            <InputNumber label="Тегло (кг)" value={form.weight_kg||""} onChange={v=>setForm({...form, weight_kg:Number(v)||undefined})} />
            <Select label="Цел" value={form.goal||"loss"} options={[["loss","Сваляне"],["maintain","Поддържане"],["gain","Покачване"]]} onChange={v=>setForm({...form, goal:v as any})} />
          </Row>
          <Row>
            <InputNumber label="Талия (см)" value={form.waist_cm||""} onChange={v=>setForm({...form, waist_cm:Number(v)||undefined})} />
            <InputNumber label="Ханш (см)" value={form.hip_cm||""} onChange={v=>setForm({...form, hip_cm:Number(v)||undefined})} />
            <Input label="Нежелани храни (запетайки)" value={form.disliked||""} onChange={v=>setForm({...form, disliked:v})} />
          </Row>
          <Row>
            <InputNumber label="Хранения/ден" value={form.meals_per_day||2} onChange={v=>setForm({...form, meals_per_day:Number(v)||2})} />
            <Input label="Фастинг прозорец" value={form.fasting_window||""} onChange={v=>setForm({...form, fasting_window:v})} />
          </Row>

          <div style={{ display:"flex", gap:12, flexWrap:"wrap" }}>
            <Button type="submit">Изпрати и изчисли</Button>
            <Button onClick={(e)=>{e.preventDefault(); const p = generatePlan(buildPayload(form,{ bmr,tdee,kcalTarget,whr,whrRisk,macros })); setPlan(p); alert("Готов 14‑дневен план.");}}>Генерирай 14‑дневен план</Button>
            <Button onClick={(e)=>{e.preventDefault(); printSummary({ form, calc:{bmr,tdee,kcalTarget,whr,whrRisk,macros}, plan }); }}>Експорт в PDF</Button>
            <Button onClick={(e)=>{e.preventDefault(); downloadJSON(plan);}}>Свали плана (JSON)</Button>
          </div>
        </form>

        <div style={{ marginTop: 16 }}>
          <h3 style={{ fontWeight: 800 }}>Резултати</h3>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:8, maxWidth:900 }}>
            <KPI label="BMR" value={`${fmt(bmr)} ккал/ден`} />
            <KPI label="TDEE" value={`${fmt(tdee)} ккал/ден`} />
            <KPI label="Целеви калории" value={`${fmt(kcalTarget)} ккал/ден`} />
            <KPI label="WHR" value={whr? whr.toFixed(2):"—"} />
            <KPI label="Риск (WHR)" value={whrRisk||"—"} />
            <KPI label="Макроси P/F/C" value={`${macros.protein_g}g / ${macros.fat_g}g / ${macros.carbs_g}g`} />
          </div>
        </div>

        {submitted && (
          <pre style={{ marginTop: 12, background:"#0b1020", color:"#e2e8f0", padding:12, borderRadius:8, overflow:"auto", maxHeight:280 }}>
{`${
  JSON.stringify({example:"payload hidden in UI preview"}, null, 2)
}`}
          </pre>
        )}

        {plan && (
          <div style={{ marginTop: 16 }}>
            <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>Преглед: 14‑дневен план</h3>
            <div style={{ border: "1px solid #e5e7eb", borderRadius: 12, overflow: "hidden" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ background: "#f1f5f9" }}>
                    <th style={{ textAlign: "left", padding: 8 }}>Ден</th>
                    <th style={{ textAlign: "left", padding: 8 }}>Хранене(я)</th>
                    <th style={{ textAlign: "right", padding: 8 }}>Ккал</th>
                  </tr>
                </thead>
                <tbody>
                  {plan.days.map((d) => (
                    <tr key={d.day}>
                      <td style={{ borderTop: "1px solid #e5e7eb", padding: 8 }}>{d.day} {d.type==="unloading"?"(разтоварващ)":""}</td>
                      <td style={{ borderTop: "1px solid #e5e7eb", padding: 8 }}>
                        <ul style={{ margin: 0, paddingLeft: 16 }}>
                          {d.meals.map((m, i) => (
                            <li key={i}><strong>{m.name}:</strong> {m.description}</li>
                          ))}
                        </ul>
                      </td>
                      <td style={{ borderTop: "1px solid #e5e7eb", padding: 8, textAlign: "right" }}>{fmt(d.kcal)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>
    </main>
  );
}

function Row({children}:{children:React.ReactNode}){ return <div style={{ display:"grid", gap:12, gridTemplateColumns:"repeat(3,1fr)" }}>{children}</div>; }
function Input({label,value,onChange}:{label:string; value:string; onChange:(v:string)=>void}){
  return <label style={{ display:"grid", gap:6 }}><span style={{ fontSize:12, color:"#475569" }}>{label}</span>
    <input value={value} onChange={e=>onChange(e.target.value)} style={{ padding:"10px 12px", border:"1px solid #cbd5e1", borderRadius:8 }} /></label>;
}
function InputNumber({label,value,onChange}:{label:string; value:any; onChange:(v:string)=>void}){
  return <label style={{ display:"grid", gap:6 }}><span style={{ fontSize:12, color:"#475569" }}>{label}</span>
    <input type="number" value={value as any} onChange={e=>onChange(e.target.value)} style={{ padding:"10px 12px", border:"1px solid #cbd5e1", borderRadius:8 }} /></label>;
}
function Select({label,value,options,onChange}:{label:string; value:any; options:[string,string][]; onChange:(v:string)=>void}){
  return <label style={{ display:"grid", gap:6 }}><span style={{ fontSize:12, color:"#475569" }}>{label}</span>
    <select value={value} onChange={e=>onChange(e.target.value)} style={{ padding:"10px 12px", border:"1px solid #cbd5e1", borderRadius:8 }}>
      {options.map(([v,l])=><option key={v} value={v}>{l}</option>)}
    </select></label>;
}
function Button({children, onClick, type}:{children:any; onClick?:(e:any)=>void; type?:"submit"|"button"}){
  return <button type={type||"button"} onClick={onClick} style={{ background:"#16a34a", border:"1px solid #16a34a", color:"#fff", padding:"10px 14px", borderRadius:10, cursor:"pointer" }}>{children}</button>;
}
function KPI({label, value}:{label:string; value:string}){
  return <div style={{ border:"1px solid #e5e7eb", borderRadius:8, padding:8 }}><div style={{ fontSize:12, color:"#64748b" }}>{label}</div><div style={{ fontWeight:800 }}>{value}</div></div>
}

function calcBMR(f:Form){
  const w = Number(f.weight_kg||0), h=Number(f.height_cm||0), a=Number(f.age||0);
  if(!w||!h||!a) return 1400;
  const base = f.sex==="male" ? (10*w + 6.25*h - 5*a + 5) : (10*w + 6.25*h - 5*a - 161);
  return Math.round(base);
}
function fmt(n:number){ return new Intl.NumberFormat("bg-BG", { maximumFractionDigits: 0 }).format(n); }

function buildPayload(form:Form, calc:any){
  return {
    contact: { full_name: form.full_name, email: form.email, phone: form.phone, sex: form.sex },
    profile: { age: form.age, height_cm: form.height_cm, weight_kg: form.weight_kg, waist_cm: form.waist_cm, hip_cm: form.hip_cm },
    activity: { level: form.activity },
    goals: { goal: form.goal, diet_type: "balanced" },
    rhythm: { meals_per_day: form.meals_per_day, fasting_window: form.fasting_window },
    preferences: { disliked_foods: form.disliked },
    targets: { bmr: calc.bmr, tdee: calc.tdee, kcal_day: calc.kcalTarget, whr: calc.whr, whr_risk: calc.whrRisk, macros: calc.macros },
    consent: true
  };
}

function generatePlan(payload:any):Plan{
  const kcalTarget = payload?.targets?.kcal_day || 1800;
  const n = payload?.rhythm?.meals_per_day || 2;
  const foods = ["пилешко филе","яйца","сирене","кашкавал","овесени ядки","пълнозърнест хляб","ориз басмати","картофи","елда","домати","краставици","моркови","зеле","спанак","броколи","чушки","зехтин","маслини","орехи","бадеми"];
  const dist = n===2?[0.6,0.4]:n===3?[0.3,0.4,0.3]:[...Array(n)].map(()=>1/n);
  const days:PlanDay[] = Array.from({length:14}).map((_,idx)=>{
    if((idx+1)%7===0){
      return { day:`Ден ${idx+1}`, type:"unloading", kcal:200, notes:"Разтоварващ ден – само течности, електролити без захар.", meals:[{ name:"Течности", kcal:200, description:"вода, билков чай, зеленчуков бульон", macros:{p:0,f:0,c:50}}] };
    }
    const meals = dist.map((share,i)=>{
      const kcal = Math.round(kcalTarget*share);
      const pick = ()=>foods[(Math.random()*foods.length)|0];
      const desc = `${pick()} + ${pick()} + ${pick()}`;
      const m = { p: Math.round(kcal*0.30/4), f: Math.round(kcal*0.35/9), c: Math.round(kcal*0.35/4) };
      const label = n===2 ? (i===0?"Обяд":"Вечеря") : n===3 ? (["Закуска","Обяд","Вечеря"][i]) : `Хранене ${i+1}`;
      return { name: label, kcal, description: desc, macros: m };
    });
    return { day:`Ден ${idx+1}`, type:"standard", kcal: Math.round(kcalTarget), notes:`Хранене в прозорец ${payload?.rhythm?.fasting_window||""}. Хидратация ≥ 30 мл/кг.`, meals };
  });
  return { meta:{ kcalTarget, mealsPerDay:n, style:"balanced", fasting: payload?.rhythm?.fasting_window }, days };
}

function printSummary({ form, calc, plan }: any) {
  const html = `<!doctype html><html><head><meta charset='utf-8' />  <title>VERDE HEALTH — Резюме</title>  <style>body{font-family:Arial,sans-serif;color:#111}h1{font-size:20px;margin:0 0 8px 0}.muted{color:#475569;font-size:12px}.kpi{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:8px 0}.box{border:1px solid #e5e7eb;border-radius:8px;padding:8px}table{width:100%;border-collapse:collapse;margin-top:8px}th,td{border-top:1px solid #e5e7eb;padding:6px;text-align:left;font-size:12px}th{background:#f1f5f9}</style>  </head><body>    <h1>VERDE HEALTH — Резюме на оценката</h1>    <div class='muted'>Дата: ${new Date().toLocaleString("bg-BG")} · Клиент: ${form.full_name||"—"} · Имейл: ${form.email||"—"}</div>    <div class='kpi'>      <div class='box'><div class='muted'>BMR</div><div><strong>${calc.bmr}</strong> ккал/ден</div></div>      <div class='box'><div class='muted'>TDEE</div><div><strong>${calc.tdee}</strong> ккал/ден</div></div>      <div class='box'><div class='muted'>Целеви калории</div><div><strong>${calc.kcalTarget}</strong> ккал/ден</div></div>    </div>    ${plan? renderPlanTable(plan):""}    <script>window.print()</script>  </body></html>`;
  const w = window.open("", "_blank");
  if (!w) return;
  w.document.write(html); w.document.close();
}
function renderPlanTable(plan:Plan){ 
  const rows = plan.days.map(d=>{
    const meals = d.meals.map(m=>`<li><strong>${m.name}:</strong> ${m.description}</li>`).join("");
    return `<tr><td>${d.day}${d.type==="unloading"?" (разтоварващ)":""}</td><td><ul>${meals}</ul></td><td style='text-align:right'>${d.kcal}</td></tr>`;
  }).join("");
  return `<h2 style='margin-top:12px'>14-дневен план</h2><table><thead><tr><th>Ден</th><th>Хранене(я)</th><th style='text-align:right'>Ккал</th></tr></thead><tbody>${rows}</tbody></table>`;
}
function downloadJSON(plan:Plan|null){
  if(!plan){ alert("Първо генерирай план."); return; }
  const blob = new Blob([JSON.stringify(plan, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob); const a = document.createElement("a");
  a.href=url; a.download="verde-plan-14d.json"; a.click(); URL.revokeObjectURL(url);
}
